package com.joking.springbootsentinel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootSentinelApplicationTests {

    @Test
    void contextLoads() {
    }

}
